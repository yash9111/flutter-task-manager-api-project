class AssetImages{
  static final String baseImagesPath = "assets/images";
  static final String backgroundImageSVG = "$baseImagesPath/background.svg";
  static final String logoImageSVG = "$baseImagesPath/logo.svg";
}