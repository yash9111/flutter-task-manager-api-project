import 'package:flutter/material.dart';
import 'package:flutter_task_manager_api_project/Data/Services/network_client.dart';
import 'package:flutter_task_manager_api_project/Data/model/Task_List_Model.dart';
import 'package:flutter_task_manager_api_project/Data/utils/urls.dart';
import 'package:flutter_task_manager_api_project/UI/widgets/TaskCard.dart';
import 'package:flutter_task_manager_api_project/UI/widgets/show_snakbar_message.dart';

import '../../Data/model/task.dart';

class CancelScreen extends StatefulWidget {
  const CancelScreen({
    super.key,
    required this.deleteTask,
    required this.getChipColor,
  });

  final Future<void> Function(Task task) deleteTask;
  final Color Function(taskStatus) getChipColor;

  @override
  State<CancelScreen> createState() => _CancelScreenState();
}

class _CancelScreenState extends State<CancelScreen> {
  bool _isGetCancelledTaskInProgress = false;
  List<Task> cancelledTaskList = [];

  @override
  void initState() {
    _getCancelledTasks();
    super.initState();
  }

  Future<void> _getCancelledTasks() async {
    _isGetCancelledTaskInProgress = true;
    setState(() {});

    NetworkResponse response = await NetworkClient.getRequest(
      url: Urls.getCanceledTaskUrl,
    );

    if (response.isSuccess) {
      TaskListModel taskListModel = TaskListModel.fromJson(response.data ?? {});
      cancelledTaskList = taskListModel.taskList;
    } else {
      showSnackBarMessage(context, "${response.errorMessage}", true);
    }

    _isGetCancelledTaskInProgress = false;
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    List<Task> cancelledTasks = cancelledTaskList
        .where((task) => task.status == taskStatus.Cancel)
        .toList();

    return ListView.separated(
      itemCount: cancelledTasks.length,
      itemBuilder: (context, index) {
        return TaskCard(
          task: cancelledTasks[index],
          getChipColor: widget.getChipColor,
          deleteTask: widget.deleteTask,
        );
      },
      separatorBuilder: (context, index) => const SizedBox(height: 5),
    );
  }
}
