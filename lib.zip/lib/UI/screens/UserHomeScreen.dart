import 'package:flutter/material.dart';
import 'package:flutter_task_manager_api_project/Data/Services/network_client.dart';
import 'package:flutter_task_manager_api_project/UI/screens/add_task.dart';
import 'package:flutter_task_manager_api_project/UI/widgets/show_snakbar_message.dart';
import 'package:flutter_task_manager_api_project/UI/widgets/summary_card.dart';
import 'package:sizer/sizer.dart';

import 'package:flutter_task_manager_api_project/Data/model/task.dart';

import '../../Data/utils/urls.dart';
import '../widgets/TMAppBar.dart';
import 'CancelTaskScreen.dart';
import 'CompletedTaskScreen.dart';
import 'NewTaskScreen.dart';
import 'ProgressTaskScreen.dart';

class UserHomeScreen extends StatefulWidget {
  UserHomeScreen({super.key});

  @override
  State<UserHomeScreen> createState() => _UserHomeScreenState();
}

class _UserHomeScreenState extends State<UserHomeScreen> {
  int selectedIndex = 0;

  @override
  Widget build(BuildContext context) {
    Color getChipColor(taskStatus status) {
      if (status == taskStatus.New) {
        return Colors.blue;
      } else if (status == taskStatus.Complete) {
        return Colors.green;
      } else if (status == taskStatus.Progress) {
        return Colors.purple;
      } else if (status == taskStatus.Cancel) {
        return Colors.red;
      }
      return Colors.white;
    }

    Future<bool> deleteTask(Task task) async{

      ScaffoldMessenger.of(context).clearSnackBars();
      NetworkResponse response = await NetworkClient.getRequest(url: Urls.deleteATaskUrl(task.id));
      if (response.isSuccess){
        showSnackBarMessage(context, "${task.title} has been deleted successfully.");
        return true;
      }else{
        showSnackBarMessage(context, "${response.errorMessage}");
        return false;
      }
    }

    List<Widget> screens = [
      NewTaskScreen(
        getChipColor: getChipColor,
        deleteTask: deleteTask,
      ),
      ProgressTaskScreen(
        getChipColor: getChipColor,
        deleteTask: deleteTask,
      ),
      CompletedTaskScreen(
        getChipColor: getChipColor,
        deleteTask: deleteTask,
      ),
      CancelScreen(
        getChipColor: getChipColor,
        deleteTask: deleteTask,
      ),
    ];

    return Scaffold(
      appBar: TMAppBar(),
      body: Column(
        children: [
          SingleChildScrollView(
            padding: EdgeInsets.symmetric(horizontal: 10.w, vertical: 2.h),
            scrollDirection: Axis.horizontal,
            child: Row(
              spacing: 10.w,
              children: [
                SummaryCard(title: "new", count: 09),
                SummaryCard(title: "progressing", count: 09),
                SummaryCard(title: "completed", count: 09),
                SummaryCard(title: "canceled", count: 09),
              ],
            ),
          ),
          Expanded(child: screens[selectedIndex]),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        backgroundColor: Colors.green,
        foregroundColor: Colors.white,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(
            50,
          ),
        ),
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => AddNewTaskScreen(),
            ),
          );
        },
        child: Icon(Icons.add),
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: selectedIndex,
        onDestinationSelected: (idx) => setState(() => selectedIndex = idx),
        destinations: [
          NavigationDestination(icon: Icon(Icons.new_label), label: 'New'),
          NavigationDestination(
            icon: Icon(Icons.ac_unit_sharp),
            label: 'Progress',
          ),
          NavigationDestination(icon: Icon(Icons.done), label: 'Completed'),
          NavigationDestination(icon: Icon(Icons.cancel), label: 'Canceled'),
        ],
      ),
    );
  }

}
