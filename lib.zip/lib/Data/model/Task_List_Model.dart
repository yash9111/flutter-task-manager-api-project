import 'dart:convert';

import 'package:flutter_task_manager_api_project/Data/model/task.dart';

class TaskListModel {
  late final String status;
  late final List<Task> taskList;

  TaskListModel.fromJson(Map<String, dynamic> jsonData) {
    status = jsonData['status'];
    if (jsonData['data'] != null) {
      List<Task> list = [];
      for (Map<String, dynamic> data in jsonData['data']) {
        list.add(Task.fromJson(jsonData));
      }
      taskList = list;
    } else {
      taskList = [];
    }
  }
}