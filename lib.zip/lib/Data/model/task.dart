import 'package:date_time_format/date_time_format.dart';

enum taskStatus{
  Progress,
  New,
  Complete,
  Cancel
}

class Task {
  late final String id;
  late final String title;
  late final String description;
  late final taskStatus status;
  late final String createdDate;

  Task.fromJson(Map<String, dynamic> jsonData){
    id = jsonData['_id'];
    title = jsonData['title'] ?? '';
    description = jsonData['description'] ?? '';
    status = jsonData['status'];
    createdDate = jsonData['createdDate'] ?? '';
  }
}