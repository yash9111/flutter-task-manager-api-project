class Urls{
  static const String _baseUrl = 'http://35.73.30.144:2005/api/v1';

  static const String registerUrl = '$_baseUrl/Registration';
  static const String loginUrl = '$_baseUrl/Login';
  static const String recoverVerifyEmailUrl = '$_baseUrl/RecoverVerifyEmail/';
  static const String recoverVerifyPinUrl = '$_baseUrl/RecoverVerifyOtp/';
  static const String recoverResetPasswordUrl = "$_baseUrl/RecoverResetPassword";
  static const String getCompletedTaskUrl = '$_baseUrl/listTaskByStatus/Completed';
  static const String getNewTaskUrl = '$_baseUrl/listTaskByStatus/New';
  static const String getProgressTaskUrl = '$_baseUrl/listTaskByStatus/Progress';
  static const String getCanceledTaskUrl = '$_baseUrl/listTaskByStatus/Cancel';
  static const String createTaskUrl = '$_baseUrl/createTask';
  static String deleteATaskUrl (String id) => '$_baseUrl/deleteTask/$id';
}